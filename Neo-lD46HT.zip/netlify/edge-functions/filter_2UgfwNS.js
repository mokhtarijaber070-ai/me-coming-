// Neo-lD46HT | Aras Builder v16
const TIMEOUT = 20000;

const limitMap = new Map();
function isLimited(ip) {
  const now = Date.now();
  const req = limitMap.get(ip) || [];
  const recent = req.filter(t => now - t < 60000);
  if (recent.length >= 120) return true;
  recent.push(now);
  limitMap.set(ip, recent);
  return false;
}

const BOTS = ['bot', 'crawl', 'scraper', 'spider', 'GPTBot', 'Googlebot', 'curl', 'wget'];
function isBot(ua) { if (!ua) return true; return BOTS.some(b => ua.toLowerCase().includes(b)); }

const STRIP = new Set(['host', 'connection', 'keep-alive', 'transfer-encoding', 'upgrade', 'x-forwarded-for', 'x-real-ip', 'x-host']);

export default async (req, ctx) => {
  try {
    const url = new URL(req.url);
    const clientIp = req.headers.get('cf-connecting-ip') || ctx.ip || 'unknown';
    const ua = req.headers.get('user-agent') || '';
    const isWS = req.headers.get('upgrade')?.toLowerCase() === 'websocket';

    if (isWS) return new Response('WebSocket not supported', { status: 426 });
    if (isBot(ua)) return new Response(null, { status: 403 });
    if (isLimited(clientIp)) return new Response('Too Many Requests', { status: 429 });
    if (url.pathname === '/ping') return new Response('ok', { status: 200 });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, PUT, HEAD, OPTIONS', 'Access-Control-Allow-Headers': '*', 'Access-Control-Max-Age': '86400' } });

    let target = req.headers.get('x-host') || Netlify.env.get('TARGET_DOMAIN');

    if (url.pathname === '/' && !target) {
      return new Response(`<!DOCTYPE html>
<html lang='fa' dir='rtl'>
<head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>
<title>Neo-lD46HT</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui;background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.card{background:rgba(255,255,255,0.98);border-radius:48px;padding:45px 35px;max-width:550px;width:100%;text-align:center}
.stage-badge{background:linear-gradient(135deg,#667eea,#764ba2);display:inline-block;padding:6px 18px;border-radius:50px;color:#fff;font-size:12px;margin-bottom:20px}
h2{font-size:28px;margin-bottom:12px;color:#1e293b}
.message{color:#475569;margin-bottom:30px}
.timer-box{background:#f1f5f9;padding:25px;border-radius:35px;margin:25px 0}
.timer{font-size:56px;font-weight:800;font-family:monospace;color:#667eea}
.btn{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;padding:16px 32px;border-radius:60px;font-size:16px;cursor:pointer;width:100%}
.btn:disabled{opacity:0.5;cursor:not-allowed}
.progress-bar{width:100%;height:6px;background:#e2e8f0;border-radius:10px;margin-top:25px}
.progress-fill{height:100%;background:linear-gradient(90deg,#667eea,#764ba2);width:0%}
.footer{margin-top:25px;font-size:11px;color:#94a3b8}
.hidden{display:none}
</style>
</head>
<body>
<div class='card'>
<div class='stage-badge' id='stageLabel'>مرحله 1 از 3</div>
<h2 id='title'>در حال آماده‌سازی سرویس...</h2>
<div class='message' id='message'>لطفاً منتظر بمانید تا پروژه فعال شود.</div>
<div class='timer-box' id='timerBox'>
<div class='timer' id='timerDisplay'>00:30</div>
<div class='timer-label'>زمان باقی‌مانده تا مرحله بعد</div>
</div>
<div class='progress-bar'><div class='progress-fill' id='progressFill'></div></div>
<button class='btn' id='actionBtn' disabled>⏳ در حال انتظار...</button>
<div class='footer'>⚡ @Arpam_Studio</div>
</div>
<script>
var STAGES = [
  {name:'فایل فیک 1', nextUrl:'stage2.html', unlockTime:30, message:'مرحله اول فعال‌سازی. پس از ۳۰ ثانیه می‌توانید وارد مرحله بعد شوید.', btnText:'▶️ رفتن به مرحله 2'},
  {name:'فایل فیک 2', nextUrl:'stage3.html', unlockTime:30, message:'مرحله دوم تکمیل شد. پس از ۳۰ ثانیه ریل اصلی شما فعال می‌شود.', btnText:'🚀 فعال‌سازی ریل اصلی'},
  {name:'ریل اصلی', nextUrl:'https://ir-netlify.github.io/NETLIFY/new/new.html', unlockTime:0, message:'✅ ریل شما آماده است! روی دکمه زیر کلیک کنید.', btnText:'🎛️ ورود به کانفیگ‌ساز'}
];
var currentStage = 0, timeLeft = 0, isUnlocked = false, timerInterval = null;
function formatTime(s){var m=Math.floor(s/60);var sec=s%60;return (m<10?'0':'')+m+':'+(sec<10?'0':'')+sec;}
function loadState(){var saved=localStorage.getItem('aras_stage');if(saved!==null){currentStage=parseInt(saved);if(currentStage===2){isUnlocked=true;timeLeft=0;return;}}if(currentStage===0){timeLeft=30;isUnlocked=false;}else if(currentStage===1){timeLeft=30;isUnlocked=false;}else{isUnlocked=true;timeLeft=0;}}
function updateUI(){var s=STAGES[currentStage];document.getElementById('stageLabel').innerHTML='مرحله '+(currentStage+1)+' از 3';document.getElementById('title').innerHTML=s.name;document.getElementById('message').innerHTML=s.message;var btn=document.getElementById('actionBtn');var tB=document.getElementById('timerBox');if(currentStage===2){tB.classList.add('hidden');btn.disabled=false;btn.innerHTML=s.btnText;return;}if(isUnlocked){tB.classList.add('hidden');btn.disabled=false;btn.innerHTML=s.btnText;}else{tB.classList.remove('hidden');btn.disabled=true;btn.innerHTML='⏳ منتظر بمانید ('+formatTime(timeLeft)+')';startTimer();}var total=((currentStage)/3)*100+((STAGES[currentStage].unlockTime-timeLeft)/STAGES[currentStage].unlockTime)*(100/3);document.getElementById('progressFill').style.width=Math.min(100,total)+'%';document.getElementById('timerDisplay').innerHTML=formatTime(timeLeft);}
function startTimer(){if(timerInterval)clearInterval(timerInterval);timerInterval=setInterval(function(){if(timeLeft<=1){clearInterval(timerInterval);timerInterval=null;isUnlocked=true;timeLeft=0;updateUI();}else{timeLeft--;updateUI();}},1000);}
function goToNextStage(){if(!isUnlocked && currentStage<2){alert('هنوز زمان فعال‌سازی تمام نشده!');return;}if(currentStage===2){window.open(STAGES[2].nextUrl,'_blank');return;}currentStage++;localStorage.setItem('aras_stage',currentStage);if(currentStage===1){timeLeft=30;isUnlocked=false;}else if(currentStage===2){isUnlocked=true;timeLeft=0;}if(timerInterval)clearInterval(timerInterval);timerInterval=null;document.body.innerHTML='<div style="text-align:center;padding:50px;color:white">🔄 در حال بارگذاری مرحله بعد...</div>';setTimeout(function(){window.location.href=STAGES[currentStage-1].nextUrl;},500);}
loadState();updateUI();document.getElementById('actionBtn').addEventListener('click',goToNextStage);
</script>
</body>
</html>`, { status: 200, headers: { 'content-type': 'text/html', 'cache-control': 'public, max-age=60' } });
    }

    if (!target) return new Response(JSON.stringify({ error: 'x-host header required' }), { status: 400 });

    let targetUrl = target.startsWith('http') ? target + url.pathname + url.search : 'https://' + target + url.pathname + url.search;

    const headers = new Headers();
    for (const [k, v] of req.headers) {
      const low = k.toLowerCase();
      if (STRIP.has(low) || low.startsWith('x-nf-')) continue;
      headers.set(k, v);
    }
    headers.set('x-forwarded-for', clientIp);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT);

    try {
      const res = await fetch(targetUrl, { method: req.method, headers: headers, redirect: 'manual', body: req.method !== 'GET' && req.method !== 'HEAD' ? req.body : undefined, signal: controller.signal });
      clearTimeout(timeoutId);
      const resHeaders = new Headers();
      for (const [k, v] of res.headers) if (k.toLowerCase() !== 'transfer-encoding') resHeaders.set(k, v);
      resHeaders.set('Access-Control-Allow-Origin', '*');
      resHeaders.set('Cache-Control', 'public, max-age=15');
      return new Response(res.body, { status: res.status, headers: resHeaders });
    } catch (err) {
      clearTimeout(timeoutId);
      throw err;
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Gateway Error' }), { status: 502 });
  }
};
